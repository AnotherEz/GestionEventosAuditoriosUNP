export { default } from './SolicitudesPage'
